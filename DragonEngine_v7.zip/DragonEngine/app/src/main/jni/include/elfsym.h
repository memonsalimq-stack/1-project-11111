// Finds an exported (dynamic) symbol of an ELF64 module that is already mapped in this process.
// Independent of game build offsets: it reads the module's own symbol table.
#pragma once
#include <elf.h>
#include <cstdint>
#include <cstring>

inline void* DragonFindExport(uintptr_t base, const char* name) {
    if (!base || !name) return nullptr;
    const Elf64_Ehdr* eh = reinterpret_cast<const Elf64_Ehdr*>(base);
    if (memcmp(eh->e_ident, ELFMAG, SELFMAG) != 0 || eh->e_ident[EI_CLASS] != ELFCLASS64) return nullptr;
    if (eh->e_phoff == 0 || eh->e_phnum == 0 || eh->e_phnum > 64) return nullptr;
    const Elf64_Phdr* ph = reinterpret_cast<const Elf64_Phdr*>(base + eh->e_phoff);

    const Elf64_Dyn* dyn = nullptr;
    for (int i = 0; i < eh->e_phnum; i++)
        if (ph[i].p_type == PT_DYNAMIC) { dyn = reinterpret_cast<const Elf64_Dyn*>(base + ph[i].p_vaddr); break; }
    if (!dyn) return nullptr;

    auto fix = [&](uint64_t p) -> uintptr_t { return p < base ? base + p : static_cast<uintptr_t>(p); };
    uintptr_t symtab = 0, strtab = 0, gnuHash = 0, sysvHash = 0;
    for (int i = 0; i < 512 && dyn[i].d_tag != DT_NULL; i++) {
        switch (dyn[i].d_tag) {
            case DT_SYMTAB: symtab = fix(dyn[i].d_un.d_ptr); break;
            case DT_STRTAB: strtab = fix(dyn[i].d_un.d_ptr); break;
            case DT_GNU_HASH: gnuHash = fix(dyn[i].d_un.d_ptr); break;
            case DT_HASH: sysvHash = fix(dyn[i].d_un.d_ptr); break;
        }
    }
    if (!symtab || !strtab) return nullptr;

    uint32_t nsyms = 0;
    if (sysvHash) {
        nsyms = reinterpret_cast<const uint32_t*>(sysvHash)[1];
    } else if (gnuHash) {
        const uint32_t* h = reinterpret_cast<const uint32_t*>(gnuHash);
        const uint32_t nbuckets = h[0], symoffset = h[1], bloomSize = h[2];
        const uint64_t* bloom = reinterpret_cast<const uint64_t*>(h + 4);
        const uint32_t* buckets = reinterpret_cast<const uint32_t*>(bloom + bloomSize);
        const uint32_t* chain = buckets + nbuckets;
        if (nbuckets == 0 || nbuckets > 1u << 20) return nullptr;
        uint32_t maxsym = 0;
        for (uint32_t i = 0; i < nbuckets; i++) if (buckets[i] > maxsym) maxsym = buckets[i];
        if (maxsym < symoffset) {
            nsyms = symoffset;
        } else {
            uint32_t guard = 0;
            while (!(chain[maxsym - symoffset] & 1u)) { maxsym++; if (++guard > (1u << 20)) return nullptr; }
            nsyms = maxsym + 1;
        }
    }
    if (nsyms == 0 || nsyms > 400000) return nullptr;

    const Elf64_Sym* syms = reinterpret_cast<const Elf64_Sym*>(symtab);
    const char* str = reinterpret_cast<const char*>(strtab);
    for (uint32_t i = 0; i < nsyms; i++) {
        if (syms[i].st_shndx == SHN_UNDEF || syms[i].st_value == 0) continue;
        if (strcmp(str + syms[i].st_name, name) == 0) return reinterpret_cast<void*>(base + syms[i].st_value);
    }
    return nullptr;
}
