// Build fingerprint: virtual-method addresses taken from the user's Universal Dumper output
// (dump.txt) of libgame-CARROM-GooglePlay-Gold-Release-Module-1473.so. All values are RVAs (base + value).
// At runtime a vtable cell must contain base + expected; the cell position inside the vtable is calibrated
// at runtime (delta 0/8/16/24 bytes) because the dumper's "vtable" address convention was not verifiable
// without the binary. A build is accepted only when most samples match.
#pragma once
#include <cstdint>

struct FpSample { uint32_t vtable; uint16_t slot; uint32_t fn; };
inline constexpr FpSample kFingerprint[] = {
    { 0x26E1848, 0, 0x1822918 },  // AndroidAttestManager
    { 0x26F2170, 0, 0x195C7D8 },  // GameTierManager
    { 0x27065B8, 0, 0x1A65B58 },  // SinglePlayerChallengesManager
    { 0x270BCA8, 0, 0x1B072E0 },  // gameplay_team
    { 0x270D288, 0, 0x1B17168 },  // recall_club_challenge
    { 0x270F148, 0, 0x1B31044 },  // club_leagues_request
    { 0x27108C0, 0, 0x1B43554 },  // ludo::dice
    { 0x2715488, 0, 0x1B924FC },  // NucleusBannersListener
    { 0x27220D8, 0, 0x1C8F65C },  // configuration::EventsLobbyModel
    { 0x2731ED0, 0, 0x1DFD5D8 },  // PackageSynchronizationManager
    { 0x273C9C0, 0, 0x1ED5604 },  // configuration::SeasonPassModel
    { 0x2742070, 0, 0x1F54428 },  // mc_gacha::proto::server_response
    { 0x27438B8, 0, 0x1F6EFA4 },  // custom_event_reward_state
    { 0x2744E98, 0, 0x1F80264 },  // custom_scoreboards_state
    { 0x2746478, 0, 0x1F97FE4 },  // ping
    { 0x2747A58, 0, 0x1FABC9C },  // ad_reward_daily_missions_state
    { 0x2749038, 0, 0x1FBB4E4 },  // gift_server_response
    { 0x274A618, 0, 0x1FC9CCC },  // lobby_client_request
    { 0x274DFC8, 0, 0x2045F64 },  // google::protobuf::EnumDescriptorProto_EnumReserved
    { 0x2750770, 0, 0x2079444 },  // google::protobuf::Struct
    { 0x27550A0, 0, 0x2272FBC },  // mc::mcCCBReader::IntegerProperty
    { 0x2760160, 0, 0x239882C },  // mc::clubs::ChatModel
    { 0x27689F0, 0, 0x24299A0 },  // mc::clubs::chat::role_message
    { 0x276A708, 0, 0x243EFC4 },  // admit_users
    { 0x276BCE8, 0, 0x244CF60 },  // search_range
    { 0x2770FD0, 0, 0x24AC210 },  // cocos2d::AudioPlayerProvider
    { 0x277A5C0, 0, 0x2684298 },  // mcwebsocketpp::exception
    { 0x2787E60, 0, 0x132ADB0 },  // UIComponentGeneratorDelegate::getProductRarityCard
    { 0x278A8F8, 0, 0x1B2E7F0 },  // gameplay_foul
    { 0x278AB58, 0, 0x1B2E9DC },  // collections_reroll_response
    { 0x278B318, 0, 0x1B5244C },  // ludo::turn_event_player_quit
    { 0x278B548, 0, 0x1B525F0 },  // ludo::referee_req_client_referee_req
    { 0x278D3D0, 0, 0x1C28290 },  // CustomScoreboardsManager
    { 0x2791B88, 0, 0x1E23E54 },  // ProfileManager
    { 0x27940E0, 0, 0x1F55A88 },  // mc_gacha::proto::chest_open_response_success_respo
    { 0x2795390, 0, 0x1FE1C10 },  // custom_event_reward_set
    { 0x27956C8, 0, 0x1FE1F40 },  // enter_game_queue_request
    { 0x2795928, 0, 0x1FE212C },  // ad_reward_reward_multiplier_state
    { 0x2795B58, 0, 0x1FE22D0 },  // friend_pending_notifications
    { 0x2799DD8, 0, 0x245D32C },  // apply_to_club
};
inline constexpr int kFingerprintCount = (int)(sizeof(kFingerprint) / sizeof(kFingerprint[0]));
