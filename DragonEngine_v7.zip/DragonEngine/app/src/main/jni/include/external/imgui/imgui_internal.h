#pragma once
// Shim: mod/keylogin.h includes "../imgui/imgui_internal.h", but the real file lives in src/.
#include "src/imgui_internal.h"
