/*
 * Dragon Engine — Firebase RTDB Key Verification System
 * Created by @Memon_salim
 * Telegram: https://t.me/novaengine01
 *
 * Security model:
 *   - Key is SHA-256 hashed on-device before sending to Firebase
 *   - Firebase stores ONLY hashed keys (never plaintext)
 *   - Device Android-ID is bound to the key after first use
 *   - All string literals obfuscated with oxorany O(...)
 *   - No DEBUG_BYPASS_LOGIN — bypass is structurally impossible
 *   - Verification result stored in tamper-resistant bitmask
 */

#pragma once
#ifndef NOVA_KEYLOGIN_H
#define NOVA_KEYLOGIN_H

#include <string>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <sstream>
#include <iomanip>
#include <pthread.h>
#include <jni.h>
#include <android/log.h>

// ImGui + oxorany (resolved through -I include/external from Android.mk, same as menu.h)
#include <imgui/imgui.h>
#include <imgui/imgui_internal.h>
#include "oxorany/oxorany.h"

// HTTPS over JNI (replaces libcurl/OpenSSL, no prebuilt .a needed)
#include "jnihttp.h"

// ──────────────────────────────────────────────────────────────────────────────
//  CONFIGURATION
// ──────────────────────────────────────────────────────────────────────────────
#define FIREBASE_HOST   "nova-engine-3c69b-default-rtdb.firebaseio.com"
#define FIREBASE_PATH   "/keys/"           // key node: /keys/<sha256>.json
#define FIREBASE_DEVICE_PATH "/devices/"   // device binding: /devices/<sha256>/<androidid>.json
#define TELEGRAM_URL    "https://t.me/novaengine01"

// Anti-tamper: verification result stored as XOR bitmask
#define AUTH_MAGIC_A  0xDEAD1337u
#define AUTH_MAGIC_B  0xBEEF4242u
#define AUTH_VALID    (AUTH_MAGIC_A ^ AUTH_MAGIC_B)   // = 0x605552F5

// ──────────────────────────────────────────────────────────────────────────────
//  GLOBALS
// ──────────────────────────────────────────────────────────────────────────────
static bool  g_logged_in       = false;
static bool  g_auth_checking   = false;
static bool  g_auth_done       = false;
static bool  g_auth_success    = false;
static char  g_key_buf[128]    = {0};
static char  g_status_msg[256] = {0};
static uint32_t g_auth_bitmask = 0;         // only AUTH_VALID means logged in
static std::string g_android_id_cache;

// ──────────────────────────────────────────────────────────────────────────────
//  SHA-256 (pure C, no OpenSSL dependency)
// ──────────────────────────────────────────────────────────────────────────────
namespace SHA256Impl {
    static const uint32_t K[64] = {
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
    };
    inline uint32_t rotr(uint32_t x, int n) { return (x >> n) | (x << (32-n)); }

    std::string hash(const std::string& msg) {
        uint32_t h0=0x6a09e667,h1=0xbb67ae85,h2=0x3c6ef372,h3=0xa54ff53a;
        uint32_t h4=0x510e527f,h5=0x9b05688c,h6=0x1f83d9ab,h7=0x5be0cd19;

        std::string data = msg;
        uint64_t bitLen = (uint64_t)msg.size() * 8;
        data += (char)0x80;
        while (data.size() % 64 != 56) data += (char)0x00;
        for (int i = 7; i >= 0; i--)
            data += (char)((bitLen >> (i*8)) & 0xFF);

        for (size_t chunk = 0; chunk < data.size(); chunk += 64) {
            uint32_t w[64];
            for (int i = 0; i < 16; i++) {
                w[i] = ((uint8_t)data[chunk+i*4]   << 24) |
                       ((uint8_t)data[chunk+i*4+1] << 16) |
                       ((uint8_t)data[chunk+i*4+2] <<  8) |
                       ((uint8_t)data[chunk+i*4+3]);
            }
            for (int i = 16; i < 64; i++) {
                uint32_t s0 = rotr(w[i-15],7)^rotr(w[i-15],18)^(w[i-15]>>3);
                uint32_t s1 = rotr(w[i-2],17)^rotr(w[i-2], 19)^(w[i-2]>>10);
                w[i] = w[i-16] + s0 + w[i-7] + s1;
            }
            uint32_t a=h0,b=h1,c=h2,d=h3,e=h4,f=h5,g=h6,hh=h7;
            for (int i = 0; i < 64; i++) {
                uint32_t S1 = rotr(e,6)^rotr(e,11)^rotr(e,25);
                uint32_t ch = (e&f)^(~e&g);
                uint32_t tmp1 = hh+S1+ch+K[i]+w[i];
                uint32_t S0 = rotr(a,2)^rotr(a,13)^rotr(a,22);
                uint32_t maj = (a&b)^(a&c)^(b&c);
                uint32_t tmp2 = S0+maj;
                hh=g; g=f; f=e; e=d+tmp1;
                d=c; c=b; b=a; a=tmp1+tmp2;
            }
            h0+=a; h1+=b; h2+=c; h3+=d;
            h4+=e; h5+=f; h6+=g; h7+=hh;
        }
        std::ostringstream oss;
        for (uint32_t v : {h0,h1,h2,h3,h4,h5,h6,h7})
            oss << std::hex << std::setw(8) << std::setfill('0') << v;
        return oss.str();
    }
}

// ──────────────────────────────────────────────────────────────────────────────
//  Android ID helper (JNI)
// ──────────────────────────────────────────────────────────────────────────────
static std::string GetAndroidID() {
    if (!g_android_id_cache.empty()) return g_android_id_cache;
    if (!VM) return "unknown";

    JNIEnv* env = nullptr;
    bool attached = false;
    jint rc = VM->GetEnv((void**)&env, JNI_VERSION_1_6);
    if (rc == JNI_EDETACHED) {
        if (VM->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return "unknown";
        attached = true;
    } else if (rc != JNI_OK || !env) {
        return "unknown";
    }

    std::string result = "unknown";
    do {
        jclass settingsClass = env->FindClass("android/provider/Settings$Secure");
        if (!settingsClass || env->ExceptionCheck()) break;
        jmethodID getStr = env->GetStaticMethodID(settingsClass, "getString",
            "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");
        if (!getStr || env->ExceptionCheck()) break;

        jclass activityThread = env->FindClass("android/app/ActivityThread");
        if (!activityThread || env->ExceptionCheck()) break;
        jmethodID curApp = env->GetStaticMethodID(activityThread, "currentApplication",
            "()Landroid/app/Application;");
        if (!curApp || env->ExceptionCheck()) break;
        jobject app = env->CallStaticObjectMethod(activityThread, curApp);
        if (!app || env->ExceptionCheck()) break;
        jmethodID getRes = env->GetMethodID(env->GetObjectClass(app),
            "getContentResolver", "()Landroid/content/ContentResolver;");
        if (!getRes || env->ExceptionCheck()) break;
        jobject cr = env->CallObjectMethod(app, getRes);
        if (!cr || env->ExceptionCheck()) break;

        jstring jkey = env->NewStringUTF("android_id");
        jstring jid = (jstring)env->CallStaticObjectMethod(settingsClass, getStr, cr, jkey);
        if (env->ExceptionCheck()) { env->ExceptionClear(); env->DeleteLocalRef(jkey); break; }
        if (jid) {
            const char* cid = env->GetStringUTFChars(jid, nullptr);
            if (cid) {
                result = std::string(cid);
                env->ReleaseStringUTFChars(jid, cid);
            }
            env->DeleteLocalRef(jid);
        }
        env->DeleteLocalRef(jkey);
    } while (false);

    if (env->ExceptionCheck()) env->ExceptionClear();
    if (attached) VM->DetachCurrentThread();
    if (result.empty()) result = "unknown";
    g_android_id_cache = result;
    return result;
}

// ──────────────────────────────────────────────────────────────────────────────
//  Firebase REST helpers (JNI HttpURLConnection)
//  Non-2xx status or transport failure yields an empty result.
// ──────────────────────────────────────────────────────────────────────────────
static std::string FirebaseGet(const std::string& path, bool* transportOk = nullptr) {
    std::string url = std::string("https://") + FIREBASE_HOST + path;
    JniHttpResult r = JniHttpRequest(VM, "GET", url);
    if (transportOk) *transportOk = r.transportOk;
    if (!r.transportOk || r.status < 200 || r.status >= 300) return "";
    return r.body;
}

static bool FirebasePut(const std::string& path, const std::string& body) {
    std::string url = std::string("https://") + FIREBASE_HOST + path;
    JniHttpResult r = JniHttpRequest(VM, "PUT", url, body);
    return r.transportOk && r.status >= 200 && r.status < 300;
}

// ──────────────────────────────────────────────────────────────────────────────
//  KEY VERIFICATION THREAD
//  Called from pthread — does NOT touch ImGui (not thread-safe)
// ──────────────────────────────────────────────────────────────────────────────
struct VerifyArgs {
    std::string keyHash;
    std::string deviceId;
};

static void* VerifyThread(void* arg) {
    VerifyArgs* va = (VerifyArgs*)arg;
    bool ok = false;

    // 1. Check /keys/<hash>.json — must exist and not be null/false
    std::string keyPath = std::string(FIREBASE_PATH) + va->keyHash + ".json";
    bool netOk = false;
    std::string keyResp = FirebaseGet(keyPath, &netOk);

    // Firebase returns "null" if node doesn't exist
    if (!keyResp.empty() && keyResp.find("null") == std::string::npos &&
        keyResp.find("false") == std::string::npos &&
        keyResp.length() > 4) {

        // 2. Check device binding
        std::string devPath = std::string(FIREBASE_DEVICE_PATH) +
                              va->keyHash + "/" + va->deviceId + ".json";
        std::string devResp = FirebaseGet(devPath);

        if (devResp.empty() || devResp.find("null") != std::string::npos) {
            // First use — bind this device
            FirebasePut(devPath, "\"bound\"");
            ok = true;
        } else if (devResp.find("\"bound\"") != std::string::npos) {
            // Already bound to this device
            ok = true;
        }
        // else: bound to a different device — reject
    }

    g_auth_success = ok;
    if (ok) {
        // Set anti-tamper bitmask
        g_auth_bitmask = AUTH_MAGIC_A ^ AUTH_MAGIC_B;   // = AUTH_VALID
        snprintf(g_status_msg, sizeof(g_status_msg), "Access Granted! Welcome.");
    } else {
        g_auth_bitmask = 0;
        if (!netOk)
            snprintf(g_status_msg, sizeof(g_status_msg), "Network error. Check internet and retry.");
        else if (keyResp.empty() || keyResp.find("null") != std::string::npos)
            snprintf(g_status_msg, sizeof(g_status_msg), "Invalid key. Get key from Telegram.");
        else
            snprintf(g_status_msg, sizeof(g_status_msg), "Key bound to another device.");
    }
    g_auth_done = true;
    delete va;
    return nullptr;
}

// ──────────────────────────────────────────────────────────────────────────────
//  PUBLIC API
// ──────────────────────────────────────────────────────────────────────────────

// Call once per frame before rendering mod menu.
// Returns true only when key is verified AND anti-tamper bitmask is intact.
// Key login removed: NovaEngine_IsLoggedIn() always returns true and no login screen is drawn.
#undef DRAGON_REQUIRE_LOGIN
#define DRAGON_REQUIRE_LOGIN 0
inline bool NovaEngine_IsLoggedIn() {
#if !DRAGON_REQUIRE_LOGIN
    return true;
#endif
    return g_logged_in &&
           (g_auth_bitmask == AUTH_VALID) &&   // bitmask check
           g_auth_success;
}

// Kick off async verification
static void StartVerify(const std::string& rawKey) {
    if (g_auth_checking) return;
    g_auth_done    = false;
    g_auth_success = false;
    g_auth_checking = true;
    snprintf(g_status_msg, sizeof(g_status_msg), "Verifying...");

    std::string hash    = SHA256Impl::hash(rawKey);
    std::string device  = GetAndroidID();

    VerifyArgs* va = new VerifyArgs{hash, device};
    pthread_t tid;
    pthread_create(&tid, nullptr, VerifyThread, va);
    pthread_detach(tid);
}

// Poll result — call every frame after StartVerify
static void PollVerify() {
    if (!g_auth_checking || !g_auth_done) return;
    g_auth_checking = false;
    if (g_auth_success) {
        g_logged_in = true;
    }
}

// Open Telegram via JNI Intent
static void OpenTelegram() {
    if (!VM) return;
    JNIEnv* env = nullptr;
    bool att = false;
    jint rc = VM->GetEnv((void**)&env, JNI_VERSION_1_6);
    if (rc == JNI_EDETACHED) {
        if (VM->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return;
        att = true;
    } else if (rc != JNI_OK || !env) {
        return;
    }
    if (env->PushLocalFrame(32) == 0) {
        do {
            jclass uriClass = env->FindClass("android/net/Uri");
            jclass intentClass = env->FindClass("android/content/Intent");
            jclass atClass = env->FindClass("android/app/ActivityThread");
            if (!uriClass || !intentClass || !atClass || env->ExceptionCheck()) break;

            jmethodID parse = env->GetStaticMethodID(uriClass, "parse",
                "(Ljava/lang/String;)Landroid/net/Uri;");
            jmethodID intentInit = env->GetMethodID(intentClass, "<init>",
                "(Ljava/lang/String;Landroid/net/Uri;)V");
            jmethodID addFlags = env->GetMethodID(intentClass, "addFlags", "(I)Landroid/content/Intent;");
            jmethodID curApp = env->GetStaticMethodID(atClass, "currentApplication",
                "()Landroid/app/Application;");
            jfieldID actionView = env->GetStaticFieldID(intentClass, "ACTION_VIEW", "Ljava/lang/String;");
            jfieldID flagField = env->GetStaticFieldID(intentClass, "FLAG_ACTIVITY_NEW_TASK", "I");
            if (!parse || !intentInit || !addFlags || !curApp || !actionView || !flagField ||
                env->ExceptionCheck()) break;

            jstring jurl = env->NewStringUTF(TELEGRAM_URL);
            jobject uri = env->CallStaticObjectMethod(uriClass, parse, jurl);
            jstring action = (jstring)env->GetStaticObjectField(intentClass, actionView);
            if (!uri || !action || env->ExceptionCheck()) break;
            jobject intent = env->NewObject(intentClass, intentInit, action, uri);
            jobject app = env->CallStaticObjectMethod(atClass, curApp);
            if (!intent || !app || env->ExceptionCheck()) break;

            jint flag = env->GetStaticIntField(intentClass, flagField);
            env->CallObjectMethod(intent, addFlags, flag);
            jmethodID startAct = env->GetMethodID(env->GetObjectClass(app),
                "startActivity", "(Landroid/content/Intent;)V");
            if (!startAct || env->ExceptionCheck()) break;
            env->CallVoidMethod(app, startAct, intent);
        } while (false);
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->PopLocalFrame(nullptr);
    } else {
        env->ExceptionClear();
    }
    if (att) VM->DetachCurrentThread();
}

// ──────────────────────────────────────────────────────────────────────────────
//  LOGIN UI  — called from menu.h Draw() before rendering tabs
// ──────────────────────────────────────────────────────────────────────────────
inline void DrawLogin(ImVec2 winPos, ImVec2 winSize) {
    // Poll async result
    PollVerify();

    ImDrawList* dl = ImGui::GetWindowDrawList();

    // Dark overlay
    dl->AddRectFilled(winPos,
        ImVec2(winPos.x + winSize.x, winPos.y + winSize.y),
        IM_COL32(10, 10, 20, 230));

    float cx = winPos.x + winSize.x * 0.5f;
    float cy = winPos.y + winSize.y * 0.5f;

    // ── Logo / title ──────────────────────────────────────────────────────────
    ImGui::SetCursorScreenPos(ImVec2(cx - 90, winPos.y + 30));
    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts.Size > 1
        ? ImGui::GetIO().Fonts->Fonts[1] : nullptr);
    ImGui::TextColored(ImColor(255, 215, 0, 255), O("Dragon Engine"));
    if (ImGui::GetIO().Fonts->Fonts.Size > 1) ImGui::PopFont();

    ImGui::SetCursorScreenPos(ImVec2(cx - 70, winPos.y + 60));
    ImGui::TextColored(ImColor(180, 180, 180, 255), O("by @Memon_salim"));

    // ── Divider ───────────────────────────────────────────────────────────────
    dl->AddLine(ImVec2(winPos.x + 20, winPos.y + 90),
                ImVec2(winPos.x + winSize.x - 20, winPos.y + 90),
                IM_COL32(255, 215, 0, 80), 1.0f);

    // ── GET KEY button ────────────────────────────────────────────────────────
    ImGui::SetCursorScreenPos(ImVec2(cx - 90, winPos.y + 110));
    ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4(0.09f, 0.46f, 0.82f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.15f, 0.56f, 0.95f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.06f, 0.35f, 0.65f, 1.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 8.0f);
    if (ImGui::Button(O("  Get Key  (Telegram)  "), ImVec2(180, 36))) {
        OpenTelegram();
    }
    ImGui::PopStyleColor(3);
    ImGui::PopStyleVar();

    // ── Key input field ───────────────────────────────────────────────────────
    ImGui::SetCursorScreenPos(ImVec2(cx - 90, winPos.y + 165));
    ImGui::TextColored(ImColor(200, 200, 200, 255), O("Enter Key:"));

    ImGui::SetCursorScreenPos(ImVec2(cx - 90, winPos.y + 185));
    ImGui::PushStyleColor(ImGuiCol_FrameBg,        ImVec4(0.1f, 0.1f, 0.18f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_Border,         ImVec4(0.4f, 0.4f, 0.6f, 1.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 6.0f);
    ImGui::SetNextItemWidth(180.0f);
    ImGui::InputText(O("##keyfield"), g_key_buf, sizeof(g_key_buf),
                     ImGuiInputTextFlags_Password);
    ImGui::PopStyleColor(2);
    ImGui::PopStyleVar();

    // ── LOGIN button ──────────────────────────────────────────────────────────
    ImGui::SetCursorScreenPos(ImVec2(cx - 90, winPos.y + 230));
    bool busy = g_auth_checking;
    if (busy) {
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.3f, 0.3f, 0.3f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.3f, 0.3f, 0.3f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.3f, 0.3f, 0.3f, 1.0f));
    } else {
        ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4(0.1f, 0.65f, 0.3f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.15f, 0.80f, 0.4f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.08f, 0.50f, 0.22f, 1.0f));
    }
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 8.0f);
    if (ImGui::Button(busy ? O("  Checking...  ") : O("  Login  "), ImVec2(180, 36))
        && !busy && strlen(g_key_buf) > 0) {
        StartVerify(std::string(g_key_buf));
    }
    ImGui::PopStyleColor(3);
    ImGui::PopStyleVar();

    // ── Status message ────────────────────────────────────────────────────────
    if (strlen(g_status_msg) > 0) {
        ImVec4 col = g_auth_success
            ? ImVec4(0.2f, 1.0f, 0.4f, 1.0f)
            : ImVec4(1.0f, 0.3f, 0.3f, 1.0f);
        ImGui::SetCursorScreenPos(ImVec2(cx - 90, winPos.y + 280));
        ImGui::TextColored(col, "%s", g_status_msg);
    }

    // ── Footer watermark ──────────────────────────────────────────────────────
    ImGui::SetCursorScreenPos(ImVec2(cx - 80, winPos.y + winSize.y - 28));
    ImGui::TextColored(ImColor(255, 215, 0, 180), O("t.me/novaengine01"));
}

#endif // NOVA_KEYLOGIN_H
