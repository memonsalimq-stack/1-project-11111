// Minimal HTTPS client over JNI (java.net.HttpURLConnection).
// Replaces libcurl + OpenSSL so the native build needs no prebuilt .a files.
// TLS and the CA store are provided by the Android runtime of the host process.
// Must be called from a non-UI thread (Android forbids network on the main thread).

#pragma once
#ifndef DRAGON_JNIHTTP_H
#define DRAGON_JNIHTTP_H

#include <jni.h>
#include <string>
#include <cstddef>

struct JniHttpResult {
    bool        transportOk = false;   // request completed and a status code was read
    int         status      = 0;       // HTTP status code, 0 if transport failed
    std::string body;                  // response body (error body for status >= 400)
};

inline JniHttpResult JniHttpRequest(JavaVM* vm, const char* method, const std::string& url,
                                    const std::string& requestBody = std::string(),
                                    int timeoutMs = 10000)
{
    JniHttpResult res;
    if (!vm || !method) return res;

    JNIEnv* env = nullptr;
    bool attached = false;
    jint rc = vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6);
    if (rc == JNI_EDETACHED) {
        if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return res;
        attached = true;
    } else if (rc != JNI_OK || !env) {
        return res;
    }

    if (env->PushLocalFrame(64) != 0) {
        env->ExceptionClear();
        if (attached) vm->DetachCurrentThread();
        return res;
    }

    // Any JNI call that can throw is followed by threw(); on a pending exception it is
    // cleared and the request is abandoned.
    auto threw = [&]() -> bool {
        if (!env->ExceptionCheck()) return false;
        env->ExceptionClear();
        return true;
    };

    jobject conn = nullptr;
    jclass  cHttp = nullptr;

    [&]() {
        jclass cURL = env->FindClass("java/net/URL");
        if (!cURL || threw()) return;
        cHttp = env->FindClass("java/net/HttpURLConnection");
        jclass cOut = env->FindClass("java/io/OutputStream");
        jclass cIn  = env->FindClass("java/io/InputStream");
        if (!cHttp || !cOut || !cIn || threw()) return;

        jmethodID urlInit  = env->GetMethodID(cURL, "<init>", "(Ljava/lang/String;)V");
        jmethodID openConn = env->GetMethodID(cURL, "openConnection", "()Ljava/net/URLConnection;");
        jmethodID setMethod = env->GetMethodID(cHttp, "setRequestMethod", "(Ljava/lang/String;)V");
        jmethodID setConnTo = env->GetMethodID(cHttp, "setConnectTimeout", "(I)V");
        jmethodID setReadTo = env->GetMethodID(cHttp, "setReadTimeout", "(I)V");
        jmethodID setCache  = env->GetMethodID(cHttp, "setUseCaches", "(Z)V");
        jmethodID setOutput = env->GetMethodID(cHttp, "setDoOutput", "(Z)V");
        jmethodID setProp   = env->GetMethodID(cHttp, "setRequestProperty",
                                               "(Ljava/lang/String;Ljava/lang/String;)V");
        jmethodID getOut    = env->GetMethodID(cHttp, "getOutputStream", "()Ljava/io/OutputStream;");
        jmethodID getCode   = env->GetMethodID(cHttp, "getResponseCode", "()I");
        jmethodID getIn     = env->GetMethodID(cHttp, "getInputStream", "()Ljava/io/InputStream;");
        jmethodID getErr    = env->GetMethodID(cHttp, "getErrorStream", "()Ljava/io/InputStream;");
        jmethodID outWrite  = env->GetMethodID(cOut, "write", "([B)V");
        jmethodID outFlush  = env->GetMethodID(cOut, "flush", "()V");
        jmethodID outClose  = env->GetMethodID(cOut, "close", "()V");
        jmethodID inRead    = env->GetMethodID(cIn, "read", "([B)I");
        jmethodID inClose   = env->GetMethodID(cIn, "close", "()V");
        if (threw() || !urlInit || !openConn || !setMethod || !setConnTo || !setReadTo || !setCache ||
            !setOutput || !setProp || !getOut || !getCode || !getIn || !getErr || !outWrite ||
            !outFlush || !outClose || !inRead || !inClose)
            return;

        jstring jurl = env->NewStringUTF(url.c_str());
        if (!jurl) { threw(); return; }
        jobject urlObj = env->NewObject(cURL, urlInit, jurl);
        if (!urlObj || threw()) return;

        conn = env->CallObjectMethod(urlObj, openConn);
        if (!conn || threw()) { conn = nullptr; return; }
        if (!env->IsInstanceOf(conn, cHttp)) { conn = nullptr; return; }

        jstring jm = env->NewStringUTF(method);
        if (!jm) { threw(); return; }
        env->CallVoidMethod(conn, setMethod, jm);
        if (threw()) return;
        env->CallVoidMethod(conn, setConnTo, static_cast<jint>(timeoutMs));
        env->CallVoidMethod(conn, setReadTo, static_cast<jint>(timeoutMs));
        env->CallVoidMethod(conn, setCache, JNI_FALSE);
        if (threw()) return;

        if (!requestBody.empty()) {
            env->CallVoidMethod(conn, setOutput, JNI_TRUE);
            jstring k = env->NewStringUTF("Content-Type");
            jstring v = env->NewStringUTF("application/json");
            if (!k || !v) { threw(); return; }
            env->CallVoidMethod(conn, setProp, k, v);
            if (threw()) return;

            jobject os = env->CallObjectMethod(conn, getOut);
            if (!os || threw()) return;
            jbyteArray arr = env->NewByteArray(static_cast<jsize>(requestBody.size()));
            if (!arr) { threw(); return; }
            env->SetByteArrayRegion(arr, 0, static_cast<jsize>(requestBody.size()),
                                    reinterpret_cast<const jbyte*>(requestBody.data()));
            env->CallVoidMethod(os, outWrite, arr);
            if (threw()) return;
            env->CallVoidMethod(os, outFlush);
            env->CallVoidMethod(os, outClose);
            if (threw()) return;
        }

        jint code = env->CallIntMethod(conn, getCode);
        if (threw()) return;
        res.status = static_cast<int>(code);

        jobject is = env->CallObjectMethod(conn, code >= 400 ? getErr : getIn);
        if (threw()) {
            // Status line was read; only the body is unavailable.
            res.transportOk = true;
            return;
        }
        if (is) {
            const jsize kChunk = 4096;
            const size_t kMaxBody = 1u << 20;   // 1 MiB cap
            jbyteArray buf = env->NewByteArray(kChunk);
            if (!buf) { threw(); return; }
            jbyte tmp[kChunk];
            bool readOk = true;
            while (res.body.size() < kMaxBody) {
                jint n = env->CallIntMethod(is, inRead, buf);
                if (threw()) { readOk = false; break; }
                if (n <= 0) break;
                env->GetByteArrayRegion(buf, 0, n, tmp);
                res.body.append(reinterpret_cast<const char*>(tmp), static_cast<size_t>(n));
            }
            env->CallVoidMethod(is, inClose);
            threw();
            if (!readOk) { res.body.clear(); return; }
        }
        res.transportOk = true;
    }();

    if (conn && cHttp) {
        jmethodID disc = env->GetMethodID(cHttp, "disconnect", "()V");
        if (disc) env->CallVoidMethod(conn, disc);
        threw();
    }

    env->PopLocalFrame(nullptr);
    if (attached) vm->DetachCurrentThread();
    return res;
}

#endif // DRAGON_JNIHTTP_H
