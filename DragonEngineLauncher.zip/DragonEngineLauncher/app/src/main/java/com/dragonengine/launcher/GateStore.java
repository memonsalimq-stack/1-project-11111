package com.dragonengine.launcher;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Whether Carrom Pool has been unlocked on this device. The access-key check
 * accepts any non-empty text (see AccessKeyActivity), so this is a cosmetic
 * gate, not a real license system.
 */
final class GateStore {
    private static final String PREFS = "dragon_gate";
    private static final String KEY_UNLOCKED = "unlocked";
    private static final String KEY_LAST_KEY = "last_key";

    private GateStore() {}

    static boolean isUnlocked(Context ctx) {
        return prefs(ctx).getBoolean(KEY_UNLOCKED, false);
    }

    static void setUnlocked(Context ctx, String enteredKey) {
        prefs(ctx).edit()
                .putBoolean(KEY_UNLOCKED, true)
                .putString(KEY_LAST_KEY, enteredKey == null ? "" : enteredKey)
                .apply();
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
