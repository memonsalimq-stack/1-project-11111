package com.dragonengine.launcher;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String CARROM_PACKAGE = "com.miniclip.carrom";
    private static final int REQ_ACCESS_KEY = 0x4452;

    private TextView txtGameStatus;
    private SlideToUnlockView slideUnlock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtGameStatus = findViewById(R.id.txtGameStatus);
        slideUnlock = findViewById(R.id.slideUnlock);

        findViewById(R.id.btnTelegram).setOnClickListener(v -> openTelegram());
        findViewById(R.id.btnShare).setOnClickListener(v -> shareApp());
        findViewById(R.id.bannerSellers).setOnClickListener(v -> openTelegram());
        findViewById(R.id.bannerLeaderboard).setOnClickListener(v ->
                Toast.makeText(this, "Leaderboard coming soon", Toast.LENGTH_SHORT).show());
        findViewById(R.id.bannerVip).setOnClickListener(v -> startAccessKeyOrLaunch());

        slideUnlock.setOnUnlockListener(this::startAccessKeyOrLaunch);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus() {
        boolean unlocked = GateStore.isUnlocked(this);
        txtGameStatus.setText(unlocked ? "Unlocked ✓" : "VIP Required");
        slideUnlock.setLabel(unlocked ? "Slide to play" : "Slide to unlock");
        slideUnlock.reset();
    }

    private void startAccessKeyOrLaunch() {
        if (GateStore.isUnlocked(this)) {
            launchCarromPool();
        } else {
            Intent i = new Intent(this, AccessKeyActivity.class);
            startActivityForResult(i, REQ_ACCESS_KEY);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_ACCESS_KEY) {
            refreshStatus();
            if (resultCode == RESULT_OK) {
                launchCarromPool();
            }
        }
    }

    private void launchCarromPool() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(CARROM_PACKAGE);
        if (launch != null) {
            startActivity(launch);
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + CARROM_PACKAGE)));
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=" + CARROM_PACKAGE)));
        }
    }

    private void openTelegram() {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.telegram_url))));
    }

    private void shareApp() {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, "Dragon Engine — " + getString(R.string.telegram_url));
        startActivity(Intent.createChooser(share, "Share Dragon Engine"));
    }
}
