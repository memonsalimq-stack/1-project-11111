package com.dragonengine.launcher;

import android.app.Activity;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Access-key gate for the ABOUT/VIP flow. Dragon Engine is now free for
 * everyone: any non-empty text in the box is accepted, so the box exists for
 * the familiar look only. See GateStore for the (cosmetic) persisted flag.
 */
public class AccessKeyActivity extends Activity {

    private EditText editKey;
    private TextView txtError;
    private ImageButton btnEye;
    private SlideToUnlockView slideUnlock;
    private boolean keyVisible = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_access_key);

        editKey = findViewById(R.id.editKey);
        txtError = findViewById(R.id.txtError);
        btnEye = findViewById(R.id.btnEye);
        slideUnlock = findViewById(R.id.slideUnlock);

        findViewById(R.id.btnPaste).setOnClickListener(v -> pasteFromClipboard());
        btnEye.setOnClickListener(v -> toggleKeyVisibility());
        findViewById(R.id.txtGoBack).setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });

        slideUnlock.setOnUnlockListener(this::attemptUnlock);
    }

    private void pasteFromClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
            CharSequence c = cm.getPrimaryClip().getItemAt(0).getText();
            if (c != null) {
                editKey.setText(c.toString().trim());
                editKey.setSelection(editKey.getText().length());
            }
        }
    }

    private void toggleKeyVisibility() {
        keyVisible = !keyVisible;
        int selStart = editKey.getSelectionStart();
        editKey.setInputType(keyVisible
                ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        btnEye.setImageResource(keyVisible ? R.drawable.ic_eye : R.drawable.ic_eye_off);
        if (selStart >= 0) editKey.setSelection(Math.min(selStart, editKey.getText().length()));
    }

    private void attemptUnlock() {
        String key = editKey.getText().toString().trim();
        if (key.isEmpty()) {
            txtError.setText("Enter any key to continue.");
            txtError.setVisibility(View.VISIBLE);
            slideUnlock.reset();
            return;
        }
        txtError.setVisibility(View.INVISIBLE);
        GateStore.setUnlocked(this, key);
        Toast.makeText(this, "Access Granted", Toast.LENGTH_SHORT).show();
        setResult(RESULT_OK);
        finish();
    }
}
