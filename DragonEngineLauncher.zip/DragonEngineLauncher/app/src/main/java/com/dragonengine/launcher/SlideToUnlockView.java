package com.dragonengine.launcher;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;

/**
 * A simple "slide to unlock" control: drag the round thumb to the right edge
 * to confirm. Snaps back if released before the threshold.
 */
public class SlideToUnlockView extends View {

    public interface OnUnlockListener {
        void onUnlocked();
    }

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint trackBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float thumbX = 0f;
    private float downX = 0f;
    private float downThumbX = 0f;
    private boolean dragging = false;
    private boolean locked = false;
    private String label = "Slide to unlock";

    private OnUnlockListener listener;

    public SlideToUnlockView(Context c, AttributeSet a) {
        super(c, a);
        trackPaint.setColor(0xFF17181C);
        trackBorderPaint.setStyle(Paint.Style.STROKE);
        trackBorderPaint.setStrokeWidth(dp(1));
        trackBorderPaint.setColor(0xFF2A2B31);
        fillPaint.setColor(0x33E2A35C);
        thumbPaint.setColor(0xFFE2A35C);
        textPaint.setColor(0xFF9A9BA3);
        textPaint.setTextSize(sp(13));
        textPaint.setTextAlign(Paint.Align.CENTER);
    }

    private float dp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, Resources.getSystem().getDisplayMetrics());
    }

    private float sp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, Resources.getSystem().getDisplayMetrics());
    }

    public void setOnUnlockListener(OnUnlockListener l) {
        this.listener = l;
    }

    public void setLabel(String text) {
        this.label = text;
        invalidate();
    }

    /** Lock the control (e.g. while an action is pending) so it ignores touches. */
    public void setLocked(boolean l) {
        this.locked = l;
    }

    public void reset() {
        thumbX = 0f;
        invalidate();
    }

    private float thumbRadius() {
        return getHeight() / 2f - dp(3);
    }

    private float maxThumbX() {
        return getWidth() - 2 * thumbRadius() - dp(6);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        RectF track = new RectF(0, 0, getWidth(), getHeight());
        float r = getHeight() / 2f;
        canvas.drawRoundRect(track, r, r, trackPaint);
        canvas.drawRoundRect(track, r, r, trackBorderPaint);

        float cx = dp(3) + thumbRadius() + thumbX;
        RectF fill = new RectF(0, 0, cx + thumbRadius() + dp(3), getHeight());
        canvas.drawRoundRect(fill, r, r, fillPaint);

        canvas.drawText(label, getWidth() / 2f, getHeight() / 2f + sp(4.5f), textPaint);

        canvas.drawCircle(cx, getHeight() / 2f, thumbRadius(), thumbPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (locked) return true;
        float cx = dp(3) + thumbRadius() + thumbX;
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (Math.abs(event.getX() - cx) < thumbRadius() * 2.2f) {
                    dragging = true;
                    downX = event.getX();
                    downThumbX = thumbX;
                    return true;
                }
                return false;
            case MotionEvent.ACTION_MOVE:
                if (dragging) {
                    float dx = event.getX() - downX;
                    thumbX = clamp(downThumbX + dx, 0, maxThumbX());
                    invalidate();
                    return true;
                }
                return false;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging) {
                    dragging = false;
                    if (thumbX > maxThumbX() * 0.82f) {
                        animateTo(maxThumbX(), true);
                    } else {
                        animateTo(0, false);
                    }
                    return true;
                }
                return false;
        }
        return super.onTouchEvent(event);
    }

    private float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private void animateTo(float target, final boolean unlocked) {
        ValueAnimator anim = ValueAnimator.ofFloat(thumbX, target);
        anim.setDuration(160);
        anim.addUpdateListener(a -> {
            thumbX = (float) a.getAnimatedValue();
            invalidate();
        });
        if (unlocked) {
            anim.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator animation) {
                    if (listener != null) listener.onUnlocked();
                }
            });
        }
        anim.start();
    }
}
